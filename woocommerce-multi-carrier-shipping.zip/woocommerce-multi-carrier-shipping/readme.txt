=== Multi-Carrier Shipping Plugin for WooCommerce ===
Contributors:extensionhawk,akshayagrawal
Version: 1.4.1

Tags: Multi Carrier Shipping, Shipping Rules, Shipping rates, Table Rates, WooCommerce, Wordpress
Requires at least: 3.0.1
Tested up to: Latest

== Description ==
== Screenshots ==
== Changelog ==
Please refer our product page for above details --> https://www.xadapter.com/product/multiple-carrier-shipping-plugin-woocommerce/

= Contact Us =
Please use our contact us form --> https://www.xadapter.com/online-support/
Or make use of questions and comments section in individual product page --> https://

== Installation ==
https://www.xadapter.com/2016/06/10/how-to-download-install-update-woocommerce-plugin/

== Tutorial / Manual ==
https://
